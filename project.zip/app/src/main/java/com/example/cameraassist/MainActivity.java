package com.example.cameraassist;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Tiny launcher screen that points the user at the Accessibility settings. */
public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        int pad = (int) (24 * getResources().getDisplayMetrics().density);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(pad, pad, pad, pad);

        TextView text = new TextView(this);
        text.setText(R.string.main_instructions);
        text.setTextSize(16f);
        text.setPadding(0, 0, 0, pad);

        Button open = new Button(this);
        open.setText(R.string.open_accessibility_settings);
        open.setOnClickListener(v ->
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));

        root.addView(text);
        root.addView(open);
        setContentView(root);
    }
}
