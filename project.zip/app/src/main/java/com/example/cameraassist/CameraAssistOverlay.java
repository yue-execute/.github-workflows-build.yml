package com.example.cameraassist;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.accessibilityservice.GestureDescription.StrokeDescription;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.widget.FrameLayout;
import android.widget.TextView;

/**
 * Floating "CA" button + look-area touch pad.
 *
 * When switched on, a nearly invisible pad covers the camera-look area. Your
 * finger drives the pad, every movement sample goes through {@link FrictionFilter},
 * and the damped result is replayed into the game as an accessibility gesture.
 *
 * The pad is made non-touchable while a swipe is running so that the replayed
 * gesture lands on the game underneath instead of on the pad itself.
 *
 * Client side only: no memory reading, no entity or target tracking.
 */
public class CameraAssistOverlay extends AccessibilityService {

    private static final String TAG = "CameraAssist";

    // Look pad region as fractions of the screen. Keep it clear of the jump,
    // sneak and attack buttons for your own HUD layout.
    private static final float PAD_LEFT = 0.45f;
    private static final float PAD_RIGHT = 0.80f;
    private static final float PAD_TOP = 0.12f;
    private static final int PAD_TINT = 0x12FFFFFF; // faint outline; 0x00000000 = invisible

    private static final long SEGMENT_MS = 20L;           // length of each replayed segment
    private static final long TAP_MS = 40L;               // duration of a replayed tap
    private static final long PASS_THROUGH_DELAY_MS = 40L; // wait for the pad to go non-touchable
    private static final int BUTTON_SIZE_DP = 52;
    private static final int DRAG_SLOP_DP = 8;

    private final Handler main = new Handler(Looper.getMainLooper());
    private final FrictionFilter filter = new FrictionFilter();

    private WindowManager wm;
    private float density;
    private int screenW;
    private int screenH;

    private TextView button;
    private WindowManager.LayoutParams buttonLp;
    private FrameLayout pad;
    private WindowManager.LayoutParams padLp;
    private boolean enabled;

    // Gesture state
    private boolean touching;          // physical finger is down on the pad
    private boolean started;           // replay has begun
    private boolean inFlight;          // a replayed segment is being dispatched
    private boolean injectedAnything;  // at least one segment was dispatched
    private int physicalDeviceId = -1;
    private int activePointerId = -1;
    private int generation;            // invalidates callbacks from older gestures
    private float injX;                // where the replayed finger is
    private float injY;
    private float tgtX;                // where the damped finger should be
    private float tgtY;
    private StrokeDescription stroke;  // last stroke that is still open, or null

    // ------------------------------------------------------------------
    // Service lifecycle
    // ------------------------------------------------------------------

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        if (button != null) return;
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        density = getResources().getDisplayMetrics().density;
        refreshScreenSize();
        createButton();
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        // Nothing to do: this service only draws overlays and replays gestures.
    }

    @Override
    public void onInterrupt() {
        abortGesture();
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        if (wm == null) return;
        refreshScreenSize();
        if (enabled) {
            abortGesture();
            removeSafely(pad);
            pad = null;
            addPad();
        }
        if (button != null) {
            int size = (int) (BUTTON_SIZE_DP * density);
            buttonLp.x = (int) clamp(buttonLp.x, 0, Math.max(0, screenW - size));
            buttonLp.y = (int) clamp(buttonLp.y, 0, Math.max(0, screenH - size));
            try {
                wm.updateViewLayout(button, buttonLp);
            } catch (IllegalArgumentException ignored) {
                // view already removed
            }
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        abortGesture();
        removeSafely(pad);
        removeSafely(button);
        pad = null;
        button = null;
    }

    @SuppressWarnings("deprecation")
    private void refreshScreenSize() {
        if (Build.VERSION.SDK_INT >= 30) {
            Rect b = wm.getMaximumWindowMetrics().getBounds();
            screenW = b.width();
            screenH = b.height();
        } else {
            DisplayMetrics dm = new DisplayMetrics();
            wm.getDefaultDisplay().getRealMetrics(dm);
            screenW = dm.widthPixels;
            screenH = dm.heightPixels;
        }
    }

    private void removeSafely(View v) {
        if (v == null) return;
        try {
            wm.removeView(v);
        } catch (IllegalArgumentException ignored) {
            // not attached
        }
    }

    // ------------------------------------------------------------------
    // Floating toggle button
    // ------------------------------------------------------------------

    private void createButton() {
        int size = (int) (BUTTON_SIZE_DP * density);

        button = new TextView(this);
        button.setText("CA");
        button.setTextColor(Color.WHITE);
        button.setGravity(Gravity.CENTER);
        button.setTextSize(14f);
        applyButtonStyle(false);

        buttonLp = new WindowManager.LayoutParams(
                size, size,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        buttonLp.gravity = Gravity.TOP | Gravity.START;
        buttonLp.x = (int) (8 * density);
        buttonLp.y = (int) (screenH * 0.4f);

        final int slop = (int) (DRAG_SLOP_DP * density);
        button.setOnTouchListener(new View.OnTouchListener() {
            private float downRawX;
            private float downRawY;
            private int startX;
            private int startY;
            private boolean dragging;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        downRawX = e.getRawX();
                        downRawY = e.getRawY();
                        startX = buttonLp.x;
                        startY = buttonLp.y;
                        dragging = false;
                        return true;
                    case MotionEvent.ACTION_MOVE: {
                        float mx = e.getRawX() - downRawX;
                        float my = e.getRawY() - downRawY;
                        if (!dragging && Math.hypot(mx, my) > slop) dragging = true;
                        if (dragging) {
                            buttonLp.x = startX + (int) mx;
                            buttonLp.y = startY + (int) my;
                            wm.updateViewLayout(button, buttonLp);
                        }
                        return true;
                    }
                    case MotionEvent.ACTION_UP:
                        if (!dragging) {
                            main.post(() -> setEnabled(!enabled));
                        }
                        return true;
                    default:
                        return false;
                }
            }
        });

        wm.addView(button, buttonLp);
    }

    private void applyButtonStyle(boolean on) {
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.OVAL);
        bg.setColor(on ? 0xCC2E7D32 : 0xCC424242);
        bg.setStroke(2, 0x88FFFFFF);
        button.setBackground(bg);
        button.setAlpha(on ? 1f : 0.7f);
    }

    // ------------------------------------------------------------------
    // Enable / disable
    // ------------------------------------------------------------------

    private void setEnabled(boolean on) {
        if (on == enabled || wm == null || button == null) return;
        enabled = on;
        applyButtonStyle(on);
        if (on) {
            addPad();
        } else {
            abortGesture();
            removeSafely(pad);
            pad = null;
        }
    }

    private void addPad() {
        int left = (int) (screenW * PAD_LEFT);
        int right = (int) (screenW * PAD_RIGHT);
        int top = (int) (screenH * PAD_TOP);

        pad = new FrameLayout(this);
        pad.setBackgroundColor(PAD_TINT);

        padLp = new WindowManager.LayoutParams(
                right - left, screenH - top,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        padLp.gravity = Gravity.TOP | Gravity.START;
        padLp.x = left;
        padLp.y = top;
        if (Build.VERSION.SDK_INT >= 28) {
            padLp.layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }

        pad.setOnTouchListener((v, e) -> {
            handlePadTouch(e);
            return true;
        });

        wm.addView(pad, padLp);

        // Keep the toggle button above the pad.
        removeSafely(button);
        wm.addView(button, buttonLp);
    }

    private void setPadTouchable(boolean touchable) {
        if (pad == null || padLp == null) return;
        if (touchable) {
            padLp.flags &= ~WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        } else {
            padLp.flags |= WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        }
        try {
            wm.updateViewLayout(pad, padLp);
        } catch (IllegalArgumentException ignored) {
            // pad already removed
        }
    }

    // ------------------------------------------------------------------
    // Physical touch -> friction filter
    // ------------------------------------------------------------------

    private void handlePadTouch(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                if (touching) return;
                beginGesture(e);
                break;

            case MotionEvent.ACTION_MOVE:
                if (!touching || e.getDeviceId() != physicalDeviceId) return;
                consumeSamples(e);
                break;

            case MotionEvent.ACTION_POINTER_UP:
                if (touching && e.getDeviceId() == physicalDeviceId
                        && e.getPointerId(e.getActionIndex()) == activePointerId) {
                    endPhysicalTouch();
                }
                break;

            case MotionEvent.ACTION_UP:
                if (!touching || e.getDeviceId() != physicalDeviceId) return;
                consumeSamples(e);
                endPhysicalTouch();
                break;

            case MotionEvent.ACTION_CANCEL:
                if (!touching || e.getDeviceId() != physicalDeviceId) return;
                Log.d(TAG, "Physical touch was cancelled by the system");
                endPhysicalTouch();
                break;

            default:
                break;
        }
    }

    private void beginGesture(MotionEvent e) {
        generation++;
        touching = true;
        started = false;
        inFlight = false;
        injectedAnything = false;
        stroke = null;
        physicalDeviceId = e.getDeviceId();
        activePointerId = e.getPointerId(0);

        injX = e.getRawX();
        injY = e.getRawY();
        tgtX = injX;
        tgtY = injY;
        filter.onDown(injX, injY, e.getEventTime());

        // Let touches pass through the pad so the replayed gesture reaches the
        // game, then start replaying once the window change has applied.
        setPadTouchable(false);
        final int gen = generation;
        main.postDelayed(() -> {
            if (gen != generation) return;
            started = true;
            pump();
        }, PASS_THROUGH_DELAY_MS);
    }

    private void consumeSamples(MotionEvent e) {
        int idx = e.findPointerIndex(activePointerId);
        if (idx < 0) return;
        // Window origin on screen, derived from pointer 0 (raw minus local).
        float offX = e.getRawX() - e.getX();
        float offY = e.getRawY() - e.getY();
        for (int h = 0; h < e.getHistorySize(); h++) {
            applySample(e.getHistoricalX(idx, h) + offX,
                    e.getHistoricalY(idx, h) + offY,
                    e.getHistoricalEventTime(h));
        }
        applySample(e.getX(idx) + offX, e.getY(idx) + offY, e.getEventTime());
        if (started) pump();
    }

    private void applySample(float x, float y, long timeMs) {
        filter.onMove(x, y, timeMs);
        tgtX = clamp(tgtX + filter.getDx(), 0f, screenW - 1f);
        tgtY = clamp(tgtY + filter.getDy(), 0f, screenH - 1f);
    }

    private void endPhysicalTouch() {
        touching = false;
        if (started) pump();
        // If replay has not started yet, the delayed start will run pump(),
        // which sees touching == false and replays a tap.
    }

    // ------------------------------------------------------------------
    // Replay the damped gesture into the game
    // ------------------------------------------------------------------

    /** Sends the next gesture segment if none is in flight. */
    private void pump() {
        if (!started || inFlight) return;

        final boolean ended = !touching;
        final float dist = (float) Math.hypot(tgtX - injX, tgtY - injY);

        if (!ended && stroke != null && dist < 1f) return; // wait for more movement
        if (ended && stroke == null && injectedAnything) {
            finishGesture();
            return;
        }

        Path p = new Path();
        p.moveTo(injX, injY);
        if (dist >= 0.5f) p.lineTo(tgtX, tgtY);

        final boolean isTap = ended && stroke == null;
        final long duration = isTap ? TAP_MS : SEGMENT_MS;
        final StrokeDescription next = (stroke == null)
                ? new StrokeDescription(p, 0, duration, !ended)
                : stroke.continueStroke(p, 0, duration, !ended);

        final float newX = tgtX;
        final float newY = tgtY;
        final int gen = generation;
        GestureDescription gesture = new GestureDescription.Builder().addStroke(next).build();

        inFlight = true;
        injectedAnything = true;
        stroke = ended ? null : next;

        boolean accepted = dispatchGesture(gesture, new GestureResultCallback() {
            @Override
            public void onCompleted(GestureDescription gd) {
                if (gen != generation) return;
                inFlight = false;
                injX = newX;
                injY = newY;
                if (ended) finishGesture();
                else pump();
            }

            @Override
            public void onCancelled(GestureDescription gd) {
                if (gen != generation) return;
                Log.d(TAG, "Replayed segment was cancelled");
                inFlight = false;
                stroke = null;
                if (touching) pump(); // start a fresh stroke from the last confirmed point
                else finishGesture();
            }
        }, null);

        if (!accepted) {
            Log.w(TAG, "dispatchGesture was rejected");
            abortGesture();
        }
    }

    /** Normal end of a swipe: reset state and make the pad touchable again. */
    private void finishGesture() {
        generation++;
        main.removeCallbacksAndMessages(null);
        touching = false;
        started = false;
        inFlight = false;
        injectedAnything = false;
        stroke = null;
        physicalDeviceId = -1;
        activePointerId = -1;
        filter.reset();
        setPadTouchable(true);
    }

    /** Abnormal end (disable, rotate, interrupt): lift any open replayed finger first. */
    private void abortGesture() {
        if (stroke != null && !inFlight) {
            try {
                Path p = new Path();
                p.moveTo(injX, injY);
                GestureDescription release = new GestureDescription.Builder()
                        .addStroke(stroke.continueStroke(p, 0, 10L, false))
                        .build();
                dispatchGesture(release, null, null);
            } catch (RuntimeException ignored) {
                // nothing more to do
            }
        }
        finishGesture();
    }

    private static float clamp(float v, float lo, float hi) {
        return v < lo ? lo : (v > hi ? hi : v);
    }
}
