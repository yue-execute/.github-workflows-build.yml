package com.example.cameraassist;

/**
 * Touch-delta friction, like thumbstick resistance on a console controller.
 *
 * Fast swipes are scaled down so they are easier to stop on a target. Slow,
 * precise movement passes through untouched. The scale eases in and out
 * instead of snapping, so it never feels like a sudden brake.
 *
 *   speed  = distance / time          (pixels per millisecond)
 *   target = 1 / (1 + strength * max(0, speed - thresholdPxPerMs))
 *   scale  = low-pass filtered target, never below minScale
 *   output = raw delta * scale
 *
 * Pure Java, no Android dependencies, so it can be unit tested anywhere.
 */
public final class FrictionFilter {

    /** Speed (px/ms) above which friction starts. 1.2 px/ms = 1200 px/s. */
    public float thresholdPxPerMs = 1.2f;
    /** How quickly friction ramps up above the threshold. */
    public float strength = 0.6f;
    /** Floor for the scale: 0.35 means a swipe is never slowed below 35%. */
    public float minScale = 0.35f;
    /** 0..1. Higher reacts faster, lower eases in more gradually. */
    public float smoothing = 0.5f;

    private float lastX;
    private float lastY;
    private long lastTimeMs;
    private float scale = 1f;
    private boolean active;

    private float outDx;
    private float outDy;

    public void reset() {
        active = false;
        scale = 1f;
        outDx = 0f;
        outDy = 0f;
    }

    public void onDown(float x, float y, long timeMs) {
        lastX = x;
        lastY = y;
        lastTimeMs = timeMs;
        scale = 1f;
        outDx = 0f;
        outDy = 0f;
        active = true;
    }

    /** Feed one raw sample, then read {@link #getDx()} and {@link #getDy()}. */
    public void onMove(float x, float y, long timeMs) {
        if (!active) {
            onDown(x, y, timeMs);
            return;
        }
        float dx = x - lastX;
        float dy = y - lastY;
        long dt = Math.max(1L, timeMs - lastTimeMs);
        float speed = (float) Math.sqrt(dx * dx + dy * dy) / dt;

        float excess = Math.max(0f, speed - thresholdPxPerMs);
        float target = 1f / (1f + strength * excess);
        if (target < minScale) target = minScale;
        if (target > 1f) target = 1f;

        scale += smoothing * (target - scale);

        outDx = dx * scale;
        outDy = dy * scale;
        lastX = x;
        lastY = y;
        lastTimeMs = timeMs;
    }

    /** Damped X delta produced by the last {@link #onMove}. */
    public float getDx() {
        return outDx;
    }

    /** Damped Y delta produced by the last {@link #onMove}. */
    public float getDy() {
        return outDy;
    }

    /** Current friction scale, 1 = no friction. */
    public float getScale() {
        return scale;
    }
}
